#!/bin/sh
nohup ./start_mining_lightbit.sh &
